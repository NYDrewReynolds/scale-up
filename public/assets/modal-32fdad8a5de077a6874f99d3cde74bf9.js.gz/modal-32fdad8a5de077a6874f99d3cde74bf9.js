var hideModal = function() {
  $(".modal-content").remove();
};
